sed -i "s/us.archi/th.archi/g" /etc/apt/sources.list

#  This is a set of scripts to install OpenStack Folsom on 
#  ubuntu 12.10. This work is inspired by the script written by  
#  Tung Ns (tungns.inf@gmail.com) at 
#       https://github.com/neophilo/openstack-scripts
#  We have divided the origiginal script into several parts and 
#  change nova-network configuration to FlatDHCP. We also write
#  a new script to install OpenStack on a compute node. 
#
#  kasidit chanchio (kasiditchanchio@gmail.com)   
#
#  ----
#
#!/bin/bash

# Check if user is root

if [ "$(id -u)" != "0" ]; then
   echo "This script must be run as root"
   echo "Please run $ sudo bash then rerun this script"
   exit 1
fi

source ~/setup_paramrc

source ~/openrc

cat >> ~/.bashrc <<EOF
source ~/openrc
EOF

source ~/.bashrc

mysql -u root -p$MYSQL_PASS -e 'CREATE DATABASE cinder_db;'
mysql -u root -p$MYSQL_PASS -e "GRANT ALL ON cinder_db.* TO 'cinder'@'%' IDENTIFIED BY 'cinder';"
mysql -u root -p$MYSQL_PASS -e "GRANT ALL ON cinder_db.* TO 'cinder'@'localhost' IDENTIFIED BY 'cinder';"

echo "
#####################################
	Install Cinder
#####################################
"
sleep 1

sudo apt-get install -y cinder-api cinder-scheduler cinder-volume iscsitarget open-iscsi iscsitarget-dkms python-cinderclient tgt

# Update /etc/cinder/api-paste.ini
sed -i "s/127.0.0.1/$IP/g" /etc/cinder/api-paste.ini
sed -i "s/%SERVICE_TENANT_NAME%/$SERVICE_TENANT/g" /etc/cinder/api-paste.ini
sed -i "s/%SERVICE_USER%/cinder/g" /etc/cinder/api-paste.ini
sed -i "s/%SERVICE_PASSWORD%/cinder/g" /etc/cinder/api-paste.ini

# Update /etc/cinder/cinder.conf
cat >> /etc/cinder/cinder.conf <<EOF
sql_connection = mysql://cinder:cinder@$IP/cinder_db
EOF

# Sync database
cinder-manage db sync

# Restart cinder service
service cinder-volume restart
service cinder-api restart

# Create 1GB test loop file, mount it then initialise it as an lvm, create a cinder-volumes group
dd if=/dev/zero of=$HOME/cinder-volumes bs=1 count=0 seek=1G
losetup /dev/loop2 $HOME/cinder-volumes
pvcreate /dev/loop2
vgcreate $HOME/cinder-volumes /dev/loop2


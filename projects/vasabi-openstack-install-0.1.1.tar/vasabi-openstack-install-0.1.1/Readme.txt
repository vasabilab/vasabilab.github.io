
The OpenStack Installation script. 
----------------------------------

This directory contains two sets of bash shell scripts to install 
OpenStack folsom software: the controller's intsallation scripts and 
the compute node's installation scripts. They are in the "Controller_node"
and "Compute_node" directory, respectively. The "Controller_node" 
contains installation scripts for OpenStack controller. There are six
installation scripts for setting up and installing various openstack 
components such as keystone, glance, and nova. The "Compute_node" 
directory, on the other hand, contains scripts for OpenStack's 
Compute node installation. These scripts will install OpenStack folsom
and use FlatDHCP network. 

These scripts are created based on the OpenStack vlan installation 
script in [1]. We have adapted some network installation tips from 
[2] and the official installation documents in [3].

Controller Node: 
================

To install OpenStack on the controller node, do the followings: 

1. Become root 

   $ sudo su
   # cd

2. Extract vasabi-openstack-install-*.tar in root's home directory

   # tar xvf vasabi-openstack-install-*.tar 

3. Change directory to vasabi-openstack-install-* and edit setup parameters

   # cd vasabi-openstack-install-*/Controller_node
   # vi setup_paramrc

4. Create a Log directory 

   # mkdir Log

5. Run installation scripts

   # ./preconfig-thai-local.sh #set ubuntu apt-get repository to local(thailand)
   # ./Install-stage1-setup.sh | tee Log/stage1.log
   # ./Install-stage2-keystone.sh | tee Log/stage2.log
   # ./Install-stage3-glance.sh | tee Log/stage3.log
   # ./Install-stage4-nova.sh | tee Log/stage4.log
   # ./Install-stage5-cinder.sh | tee Log/stage5.log
   # ./Install-stage6-horizon.sh | tee Log/stage6.log

6. Reboot 

   # reboot

7. Check out service availability 

   $ sudo su
   # nova-manage service list 

8. In case the above command report "XXX" error on some service, 
   restart all nova services using nova_restart acript

   # cd /root
   # ./nova_restart

8. Use browser to access OpenStack Horizon on the Controller node 


Compute Node: 
=============

To install OpenStack on a compute node, do the followings: 

1. Become root 

   $ sudo su
   # cd

2. Extract vasabi-openstack-install-*.tar in root's home directory

   # tar xvf vasabi-openstack-install-*.tar 

3. Change directory to vasabi-openstack-install-* and edit parameters

   # cd vasabi-openstack-install-*/Compute_node
   # mkdir Log
   # vi setup_compute_node_paramrc

4. Run scripts

   # ./preconfig-thai-local.sh 
   # ./Install-compute-node.sh | tee Log/Compute.log
   
5. Use OpenStack 

Uninstallation:
===============

To uninstall OpenStack, cd to either "Controller_node" or "Compute_node" 
and run

  # ./remove.sh

-kasidit (kasiditchanchio@gmail.com)
 Vasabilab, Dept of Computer Science, 
 Faculty of Science and Technology, 
 Thammasat University
 http://vasabilab.cs.tu.ac.th

References.

[1] Tung Ns, https://github.com/neophilo/openstack-scripts
[2] https://github.com/mseknibilel/OpenStack-Folsom-Install-guide
[3] www.openstack.org/software/start/

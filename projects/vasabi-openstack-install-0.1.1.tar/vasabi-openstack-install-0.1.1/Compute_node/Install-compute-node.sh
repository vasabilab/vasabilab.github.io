#  This is a set of scripts to install OpenStack Folsom on 
#  ubuntu 12.10. This work is inspired by the script written by  
#  Tung Ns (tungns.inf@gmail.com) at 
#       https://github.com/neophilo/openstack-scripts
#
#  We have divided the origiginal script into several parts and 
#  change nova-network configuration to FlatDHCP. We also write
#  a new script to install OpenStack on a compute node. 
#
#  kasidit chanchio (kasiditchanchio@gmail.com)   
#  vasabilab, Department of Computer Science, 
#  Faculty of Science & Technology, Thammasat Univrersity
#
#  ----
#
#!/bin/bash

# Check if user is root

if [ "$(id -u)" != "0" ]; then
   echo "This script must be run as root"
   echo "Please run $ sudo bash then rerun this script"
   exit 1
fi

cp ./setup_compute_node_paramrc ~/setup_compute_node_paramrc
source ~/setup_compute_node_paramrc

##### Pre-configure #####
# Enable Cloud Archive repository for Ubuntu

cat > /etc/apt/sources.list.d/folsom.list <<EOF
deb http://ubuntu-cloud.archive.canonical.com/ubuntu precise-updates/folsom main
EOF

# update Ubuntu
apt-get update
# add the public key for the folsom repository
apt-get install ubuntu-cloud-keyring
# update Ubuntu
apt-get update

apt-get upgrade -y

apt-get install vlan bridge-utils

echo "
######################################
	Install ntp server
######################################
"
sleep 1

apt-get install -y ntp

sed -i "s/server ntp.ubuntu.com/server $CONTROLLER_PRIVATE_IP/g" /etc/ntp.conf
service ntp restart

echo "
######################################
	Enable ip forwarding
######################################
"
#cp /etc/sysctl.conf /root/sysctl.conf.backup
sed -i "s/#net.ipv4.ip_forward=1/net.ipv4.ip_forward=1/g" /etc/sysctl.conf
sysctl net.ipv4.ip_forward=1
sleep 1

echo "
#####################################
	Install Nova
#####################################
"
sleep 2

# Check to install nova-compute-kvm or nova-compute-qemu

if [ $HYPERVISOR == "qemu" ]; then
	apt-get -y install nova-compute nova-compute-qemu
else
	apt-get -y install nova-compute nova-compute-kvm
fi

apt-get install -y nova-network nova-api-metadata novnc

# Update hypervisor in nova-compute.conf

if [ $HYPERVISOR == "qemu" ]; then
	sed -i 's/kvm/qemu/g' /etc/nova/nova-compute.conf
fi

# Update nova.conf

cat > /etc/nova/nova.conf <<EOF
[DEFAULT]

# LOG/STATE
verbose=True
logdir=/var/log/nova
state_path=/var/lib/nova
lock_path=/var/lock/nova

# AUTHENTICATION
auth_strategy=keystone
keystone_ec2_url=http://$CONTROLLER_PRIVATE_IP:5000/v2.0/ec2tokens

# SCHEDULER
scheduler_driver=nova.scheduler.simple.SimpleScheduler
compute_scheduler_driver=nova.scheduler.filter_scheduler.FilterScheduler

# DATABASE
sql_connection=mysql://nova:nova@$CONTROLLER_PRIVATE_IP/nova_db

# NETWORK
network_manager=nova.network.manager.FlatDHCPManager
dhcpbridge_flagfile=/etc/nova/nova.conf
dhcpbridge=/usr/bin/nova-dhcpbridge
public_interface=$PUBLIC_NIC
flat_interface=$PRIVATE_NIC
flat_network_bridge=br100
fixed_range=$VMNET_IP_RANGE
network_size=$VMNET_NET_SIZE
flat_injected=False
force_dhcp_release=True
#iscsi_helper=ietadm
my_ip=$THIS_COMPUTE_NODE_PUBLIC_IP
multi_host=True
#firewall_driver=nova.virt.libvirt.firewall.IptablesFirewallDriver

# NOVNC
novnc_enabled=true
novncproxy_base_url=http://$CONTROLLER_PUBLIC_IP:6080/vnc_auto.html
vncserver_listen=$THIS_COMPUTE_NODE_PUBLIC_IP
vncserver_proxyclient_address=$THIS_COMPUTE_NODE_PUBLIC_IP

# APIs
#osapi_compute_extension=nova.api.openstack.compute.contrib.standard_extensions
s3_host=$CONTROLLER_PRIVATE_IP
ec2_host=$CONTROLLER_PRIVATE_IP
#ec2_dmz_host=$CONTROLLER_PRIVATE_IP
cc_host=$CONTROLLER_PRIVATE_IP
metadata_host=$CONTROLLER_PRIVATE_IP
#enabled_apis=ec2,osapi_compute,metadata
nova_url=http://$CONTROLLER_PRIVATE_IP:8774/v1.1/
ec2_url=http://$CONTROLLER_PRIVATE_IP:8773/services/Cloud
#volume_api_class=nova.volume.cinder.API

# RABBIT
rabbit_host=$CONTROLLER_PRIVATE_IP

# GLANCE
glance_api_servers=$CONTROLLER_PRIVATE_IP:9292
image_service=nova.image.glance.GlanceImageService

# COMPUTE
#connection_type=libvirt
compute_driver=libvirt.LibvirtDriver
libvirt_type=qemu
libvirt_cpu_mode=none
#allow_resize_to_same_host=True
#libvirt_use_virtio_for_bridges=true
start_guests_on_host_boot=True
resume_guests_state_on_host_boot=True
api_paste_config=/etc/nova/api-paste.ini
allow_admin_api=True
use_deprecated_auth=False
rootwrap_config=/etc/nova/rootwrap.conf
root_helper=sudo nova-rootwrap /etc/nova/rootwrap.conf
#instance_name_template=instance-%08x

# CINDER
volume_api_class=nova.volume.cinder.API
osapi_volume_listen_port=5900
EOF

cat > ~/nova_restart <<EOF
sudo restart libvirt-bin
for i in nova-network nova-compute nova-api-metadata
do
sudo service "\$i" restart # need \ before $ to make it a normal charactor not variable
done
EOF

chmod +x ~/nova_restart

~/nova_restart

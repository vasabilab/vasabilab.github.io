
/*
 *  IA64 emulation helpers for qemu. (Leave it as blank now.)
 *
 */

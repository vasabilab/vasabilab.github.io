/*
 * QEMU live migration
 *
 * Copyright IBM, Corp. 2008
 *
 * Authors:
 *  Anthony Liguori   <aliguori@us.ibm.com>
 *
 * This work is licensed under the terms of the GNU GPL, version 2.  See
 * the COPYING file in the top-level directory.
 *
 */

#include "qemu-common.h"
#include "migration.h"
#include "monitor.h"
#include "buffered_file.h"
#include "sysemu.h"
#include "block.h"
#include "qemu_socket.h"

#include "qemu-timer.h"
#include <pthread.h>
#include <sched.h>
#include <utmpx.h>

//#define DEBUG_MIGRATION

#ifdef DEBUG_MIGRATION
#define dprintf(fmt, ...) \
    do { printf("migration: " fmt, ## __VA_ARGS__); } while (0)
#else
#define dprintf(fmt, ...) \
    do { } while (0)
#endif

/* Migration speed throttling */
static uint32_t max_throttle = (32 << 20);

static MigrationState *current_migration;

//Migration timing
#define QEMU_TIMER_REALTIME 0
struct QEMUClock {
    int type;
};
QEMUClock *mig_rt_clock;
int64_t mig_start, mig_finish;
int64_t stage_start, stage_finish;
int64_t dt_start, dt_finish;
int exec = 0;
//ram bytes transferred stage 1 2 3
uint64_t ram_transferred_s1, ram_transferred_s2, ram_transferred_s3;
int ncpus;
pthread_t do_migrate_id;
cpu_set_t cpuset;
pthread_mutex_t *lock_phys_ram_dirty;  //vm-thread synchronization
int mthread;

typedef struct {
    Monitor *mon;
    int detach;
    const char *uri;
} Tmig;

Tmig t;

static QEMUClock *qemu_new_clock(int type)
{
    QEMUClock *clock;
    clock = qemu_mallocz(sizeof(QEMUClock));
    clock->type = type;
    return clock;
}

void qemu_start_incoming_migration(const char *uri)
{
    const char *p;

    if (strstart(uri, "tcp:", &p))
        tcp_start_incoming_migration(p);
#if !defined(WIN32)
    else if (strstart(uri, "exec:", &p))
        exec_start_incoming_migration(p);
#endif
    else
        fprintf(stderr, "unknown migration protocol: %s\n", uri);
}

void do_migrate_state(Monitor *mon, int detach, const char *uri)
{
    MigrationState *s = NULL;
    const char *p;

    //Setup mig_rt_clock
    //mig_rt_clock = qemu_new_clock(QEMU_TIMER_REALTIME);
    
    monitor_printf(mon, "vl: execute on cpu %d\n", vl_cpu);
    monitor_printf(mon, "do_migrate id: %u\n", (unsigned int)do_migrate_id);
    monitor_printf(mon, "created thread id: %u\n", (unsigned int)pthread_self());

    //Start migration timing
    //mig_start = qemu_get_clock(mig_rt_clock);

    if (strstart(uri, "tcp:", &p))
        s = tcp_start_outgoing_migration(p, max_throttle, detach);
#if !defined(WIN32)
    else if (strstart(uri, "exec:", &p)){
        exec = 1;
        s = exec_start_outgoing_migration(p, max_throttle, detach);
    }
#endif
    else
        monitor_printf(mon, "unknown migration protocol: %s\n", uri);

    if (s == NULL)
        monitor_printf(mon, "migration failed\n");
    else {
        if (current_migration)
            current_migration->release(current_migration);

        current_migration = s;
    }
    if (mthread) {
        while (!idone)
            buffered_rate_tick_t();
    }
}

void *do_migrate_t(void *arg)
{
    int cpu, i;
    CPU_ZERO(&cpuset);
    pthread_mutex_t mutex[dirty_size];

    for (cpu = 0; cpu < ncpus; cpu++)
      CPU_SET(cpu, &cpuset);

    lock_phys_ram_dirty = mutex;
    for (i = 0; i < dirty_size; i++)
        pthread_mutex_init(&mutex[i], NULL);
        
    do_migrate_state(t.mon, t.detach, t.uri);
}

void do_migrate(Monitor *mon, int detach, const char *uri)
{
    ncpus = (int)sysconf(_SC_NPROCESSORS_ONLN);

    mig_rt_clock = qemu_new_clock(QEMU_TIMER_REALTIME);
    mig_start = qemu_get_clock(mig_rt_clock);

    if (ncpus > 1) {
        mthread = 1;
        t.mon = mon;
        t.detach = detach;
        t.uri = uri;
        pthread_t thread;

        pthread_create(&thread, NULL, do_migrate_t, NULL);
        pthread_detach(thread);
        do_migrate_id = pthread_self();
        sleep(1);
    } else {
        do_migrate_state(mon, detach, uri);
    }
}

void do_migrate_cancel(Monitor *mon)
{
    MigrationState *s = current_migration;

    if (s)
        s->cancel(s);
}

void do_migrate_set_speed(Monitor *mon, const char *value)
{
    double d;
    char *ptr;
    FdMigrationState *s;

    d = strtod(value, &ptr);
    switch (*ptr) {
    case 'G': case 'g':
        d *= 1024;
    case 'M': case 'm':
        d *= 1024;
    case 'K': case 'k':
        d *= 1024;
    default:
        break;
    }

    max_throttle = (uint32_t)d;
    s = migrate_to_fms(current_migration);

    if (s) {
        qemu_file_set_rate_limit(s->file, max_throttle);
    }
    
}

/* amount of nanoseconds we are willing to wait for migration to be down.
 * the choice of nanoseconds is because it is the maximum resolution that
 * get_clock() can achieve. It is an internal measure. All user-visible
 * units must be in seconds */
static uint64_t max_downtime = 30000000;

uint64_t migrate_max_downtime(void)
{
    return max_downtime;
}

void do_migrate_set_downtime(Monitor *mon, const char *value)
{
    char *ptr;
    double d;

    d = strtod(value, &ptr);
    if (!strcmp(ptr,"ms")) {
        d *= 1000000;
    } else if (!strcmp(ptr,"us")) {
        d *= 1000;
    } else if (!strcmp(ptr,"ns")) {
    } else {
        /* all else considered to be seconds */
        d *= 1000000000;
    }

    max_downtime = (uint64_t)d;
}

void do_info_migrate(Monitor *mon)
{
    MigrationState *s = current_migration;

    if (s) {
        monitor_printf(mon, "Migration status: ");
        switch (s->get_status(s)) {
        case MIG_STATE_ACTIVE:
            monitor_printf(mon, "active\n");
            monitor_printf(mon, "transferred ram: %" PRIu64 " kbytes\n", ram_bytes_transferred() >> 10);
            monitor_printf(mon, "remaining ram: %" PRIu64 " kbytes\n", ram_bytes_remaining() >> 10);
            monitor_printf(mon, "total ram: %" PRIu64 " kbytes\n", ram_bytes_total() >> 10);
            break;
        case MIG_STATE_COMPLETED:
            monitor_printf(mon, "completed\n");
            break;
        case MIG_STATE_ERROR:
            monitor_printf(mon, "failed\n");
            break;
        case MIG_STATE_CANCELLED:
            monitor_printf(mon, "cancelled\n");
            break;
        }
    }
}

/* shared migration helpers */

void migrate_fd_monitor_suspend(FdMigrationState *s)
{
    s->mon_resume = cur_mon;
    if (monitor_suspend(cur_mon) == 0)
        dprintf("suspending monitor\n");
    else
        monitor_printf(cur_mon, "terminal does not allow synchronous "
                       "migration, continuing detached\n");
}

void migrate_fd_error(FdMigrationState *s)
{
    dprintf("setting error state\n");
    s->state = MIG_STATE_ERROR;
    migrate_fd_cleanup(s);
}

void migrate_fd_cleanup(FdMigrationState *s)
{
    qemu_set_fd_handler2(s->fd, NULL, NULL, NULL, NULL);

    if (s->file) {
        dprintf("closing file\n");
        qemu_fclose(s->file);
    }

    if (s->fd != -1)
        close(s->fd);

    /* Don't resume monitor until we've flushed all of the buffers */
    if (s->mon_resume)
        monitor_resume(s->mon_resume);

    s->fd = -1;
}

void migrate_fd_put_notify(void *opaque)
{
    FdMigrationState *s = opaque;

    qemu_set_fd_handler2(s->fd, NULL, NULL, NULL, NULL);
    qemu_file_put_notify(s->file);
}

ssize_t migrate_fd_put_buffer(void *opaque, const void *data, size_t size)
{
    FdMigrationState *s = opaque;
    ssize_t ret;

    do {
        ret = s->write(s, data, size);
    } while (ret == -1 && ((s->get_error(s)) == EINTR));

    if (ret == -1)
        ret = -(s->get_error(s));

    if (ret == -EAGAIN)
        qemu_set_fd_handler2(s->fd, NULL, NULL, migrate_fd_put_notify, s);

    return ret;
}

void migrate_fd_connect(FdMigrationState *s)
{
    int ret;

    s->file = qemu_fopen_ops_buffered(s,
                                      s->bandwidth_limit,
                                      migrate_fd_put_buffer,
                                      migrate_fd_put_ready,
                                      migrate_fd_wait_for_unfreeze,
                                      migrate_fd_close);

    dprintf("beginning savevm\n");

    //Start migration stage 1: transfer all memory pages
    if (mthread) {
        idone = 0;
        monitor_printf(cur_mon, "migration stage 1: transfer all memory pages:: thread id %u on cpu %d\n", (unsigned int)pthread_self(), sched_getcpu());
    } else {
        monitor_printf(cur_mon, "migration stage 1: transfer all memory pages\n");
    }
    stage_start = qemu_get_clock(mig_rt_clock);

    ret = qemu_savevm_state_begin(s->file);

    //Finish migration stage 1: transfer all memory pages
    stage_finish = qemu_get_clock(mig_rt_clock);

    if (ret < 0) {
        dprintf("failed, %d\n", ret);
        migrate_fd_error(s);
        return;
    }

    //Display elapsed time for migration stage 1
    monitor_printf(cur_mon, "elapsed time for migration stage 1: %" PRId64 " ms\n", stage_finish - stage_start);
    ram_transferred_s1 = ram_bytes_transferred() >> 10;
    monitor_printf(cur_mon, "stage 1: transferred ram: %" PRIu64 " kbytes\n", ram_transferred_s1);
    
    migrate_fd_put_ready(s);
}

void migrate_fd_put_ready(void *opaque)
{
    FdMigrationState *s = opaque;

    static int iterate = 0;
    int i;

    if (s->state != MIG_STATE_ACTIVE) {
        dprintf("put_ready returning because of non-active state\n");
        return;
    }

    dprintf("iterate\n");

    //Start migration stage 2: transfer all dirty pages
    if (iterate == 0) {
        if (mthread) {
            CPU_CLR(vl_cpu, &cpuset);
            if (pthread_setaffinity_np(pthread_self(), sizeof(cpu_set_t), &cpuset) != 0)
                monitor_printf(cur_mon, "thread error: sched_setaffinity\n");
            
            monitor_printf(cur_mon, "migration stage 2: transfer all dirty pages:: thread id %u on cpu %d\n", (unsigned int)pthread_self(), sched_getcpu());
        } else {
            monitor_printf(cur_mon, "migration stage 2: transfer all dirty pages\n");
        }
        stage_start = qemu_get_clock(mig_rt_clock);
    }

//thread
  if (!(mthread && (pthread_self() == do_migrate_id))) {
    if ((qemu_savevm_state_iterate(s->file) == 1) || (iterate >= 200)) {
        //Finish migration stage 2: transfer all dirty pages
        stage_finish = qemu_get_clock(mig_rt_clock);

        monitor_printf(cur_mon, "%d iterate done\n", iterate);
        //Display elapsed time for migration stage 2
        monitor_printf(cur_mon, "elapsed time for migration stage 2: %" PRId64 " ms\n", stage_finish - stage_start);
        ram_transferred_s2 = (ram_bytes_transferred() >> 10) - ram_transferred_s1;
        monitor_printf(cur_mon, "stage 2: transferred ram: %" PRIu64 " kbytes\n", ram_transferred_s2);
        idone = 1;
    } else {
        iterate++;
    }
  }

//master
      if (idone && !(mthread && (pthread_self() != do_migrate_id))) {
        int state;
        dprintf("done iterating\n");

        //Stop vm
        monitor_printf(cur_mon, "stop vm\n");
        dt_start = qemu_get_clock(mig_rt_clock);
        vm_stop(0);

        bdrv_flush_all();

        //Start migration stage 3: transfer vm state and remaining dirty pages
        if (mthread) {
            monitor_printf(cur_mon, "migration stage 3: transfer vm state and remaining dirty pages:: thread id %u on cpu %d\n", (unsigned int)pthread_self(), sched_getcpu());
        } else {
            monitor_printf(cur_mon, "migration stage 3: transfer vm state and remaining dirty pages\n");
        }
        stage_start = qemu_get_clock(mig_rt_clock);

        if ((qemu_savevm_state_complete(s->file)) < 0) {
            vm_start();
            state = MIG_STATE_ERROR;
        } else {
            state = MIG_STATE_COMPLETED;
            //In case of exec protocol, restart vm
            if(exec){
                monitor_printf(cur_mon, "start vm\n");
                vm_start();
            }
        }

        //Finish migration stage 3: transfer vm state and remaining dirty pages & migration timing
        mig_finish = dt_finish = stage_finish = qemu_get_clock(mig_rt_clock);

        //Display elapsed time for migration stage 3
        monitor_printf(cur_mon, "elapsed time for migration stage 3: %" PRId64 " ms\n", stage_finish - stage_start);
        ram_transferred_s3 = (ram_bytes_transferred() >> 10) - ram_transferred_s1 - ram_transferred_s2;
        monitor_printf(cur_mon, "stage 3: transferred ram: %" PRIu64 " kbytes\n", ram_transferred_s3);

        //Display migration elapsed time
        monitor_printf(cur_mon, "elapsed time for migration: %" PRId64 " ms\n", mig_finish - mig_start);
        monitor_printf(cur_mon, "total ram transferred: %" PRIu64 " kbytes\n", ram_bytes_transferred() >> 10);
        monitor_printf(cur_mon, "downtime: %" PRId64 " ms\n", dt_finish - dt_start + setup_dt);
        //monitor_printf(cur_mon, "check thread state: %" PRId64 " us\n", checktime);

        iterate = 0;
        idone = 0;
        migrate_fd_cleanup(s);
        s->state = state;
        qemu_free(mig_rt_clock);
        for (i = 0; i < dirty_size; i++)
            pthread_mutex_destroy(lock_phys_ram_dirty+i);
    }
}

int migrate_fd_get_status(MigrationState *mig_state)
{
    FdMigrationState *s = migrate_to_fms(mig_state);
    return s->state;
}

void migrate_fd_cancel(MigrationState *mig_state)
{
    FdMigrationState *s = migrate_to_fms(mig_state);

    if (s->state != MIG_STATE_ACTIVE)
        return;

    dprintf("cancelling migration\n");

    s->state = MIG_STATE_CANCELLED;

    migrate_fd_cleanup(s);
}

void migrate_fd_release(MigrationState *mig_state)
{
    FdMigrationState *s = migrate_to_fms(mig_state);

    dprintf("releasing state\n");
   
    if (s->state == MIG_STATE_ACTIVE) {
        s->state = MIG_STATE_CANCELLED;
        migrate_fd_cleanup(s);
    }
    free(s);
}

void migrate_fd_wait_for_unfreeze(void *opaque)
{
    FdMigrationState *s = opaque;
    int ret;

    dprintf("wait for unfreeze\n");
    if (s->state != MIG_STATE_ACTIVE)
        return;

    do {
        fd_set wfds;

        FD_ZERO(&wfds);
        FD_SET(s->fd, &wfds);

        ret = select(s->fd + 1, NULL, &wfds, NULL, NULL);
    } while (ret == -1 && (s->get_error(s)) == EINTR);
}

int migrate_fd_close(void *opaque)
{
    FdMigrationState *s = opaque;

    qemu_set_fd_handler2(s->fd, NULL, NULL, NULL, NULL);
    return s->close(s);
}

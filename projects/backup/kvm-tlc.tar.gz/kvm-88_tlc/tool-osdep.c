/* Hack to provide a version of osdep.o for qemu-img without conflicting with
   the (kqemu) target specific osdep.o.  */
#include "osdep.c"


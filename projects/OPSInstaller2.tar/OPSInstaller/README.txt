OpenStack Icehouse Installation Script 
by the vasabilab team

Copyright 2014 the vasabilab team 

Team members: 
	Kasidit Chanchio
	Vasinee Siripoon
	Somkiat Kosolsombat
	Phithak Thaenkaew
	Chayawat Pechwises

Contact: kasiditchanchio@gmail.com

Note: This script is written for education purpose. 
Use at your own risks. Let us know if you want 
to harden it. 

Please consult more info from the OpenStack documantation site.

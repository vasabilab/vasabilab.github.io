# Openstack icehouse installation script 
# on ubuntu 14.04 by kasidit chanchio
# vasabilab, dept of computer science, Thammasat University, Thailand
# copyright 2014 
#
#
#!/bin/bash -x
cd $HOME/OPSInstaller/Controller
pwd
echo "Run this script with sudo or as root."
echo -n "1. reconfig nova...press"
read varkey

cp files/nova_stage24.conf /etc/nova/nova.conf 

printf "\n2. restart nova ..press"
read varkey

service nova-api restart

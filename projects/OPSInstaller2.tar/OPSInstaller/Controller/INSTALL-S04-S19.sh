# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
#!/bin/bash -x
#
cd $HOME/OPSInstaller/Controller
pwd
sudo /bin/bash -x ./stage04-SUDO-mysql.sh | tee log/s04.log
printf "\n Next? \n"
read varkey
clear
sudo /bin/bash -x ./stage07-SUDO-rabbit.sh | tee log/s07.log
printf "\n Next? \n"
read varkey
clear
sudo /bin/bash -x ./stage08-SUDO-keystone.sh | tee log/s08.log
printf "\n Next? \n"
read varkey
clear
/bin/bash -x ./stage09-USER-define-keystone-users.sh | tee log/s09.log
printf "\n Next? \n"
read varkey
clear
/bin/bash -x ./stage10-USER-service-endpoints.sh | tee log/s10.log
printf "\n Next? \n"
read varkey
clear
sudo /bin/bash -x ./stage11-SUDO-install-pip.sh | tee log/s11.log
printf "\n Next? \n"
read varkey
clear
sudo /bin/bash -x ./stage12-SUDO-glance.sh 2>&1 | tee log/s12.log
printf "\n Next? \n"
read varkey
clear
/bin/bash -x ./stage13-USER-glance-endpoint.sh 2>&1 | tee log/s13.log
printf "\n Next? \n"
read varkey
clear
sudo /bin/bash -x ./stage14-SUDO-restart-glance.sh 2>&1 | tee log/s14.log
printf "\n Next? \n"
read varkey
clear
/bin/bash -x ./stage15-USER-verify-glance.sh  2>&1 | tee log/s15.log
printf "\n Next? \n"
read varkey
clear
sudo /bin/bash -x ./stage16-SUDO-control-nova.sh 2>&1 | tee log/s16.log
printf "\n Next? \n"
read varkey
clear
/bin/bash -x ./stage17-USER-nova-endpoint.sh 2>&1 | tee log/s17.log
printf "\n Next? \n"
read varkey
clear
sudo /bin/bash -x ./stage18-SUDO-restart-nova.sh 2>&1 | tee log/s18.log
printf "\n Next? \n"
read varkey
clear
/bin/bash -x ./stage19-USER-verify-nova.sh 2>&1 | tee log/s19.log
printf "\n End 19 \n"
read varkey
#sudo /bin/bash -x ./stageFIN-SUDO-postinstall.sh

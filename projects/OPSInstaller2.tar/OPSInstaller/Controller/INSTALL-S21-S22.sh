# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
#!/bin/bash -x
#
cd $HOME/OPSInstaller/Controller
pwd
/bin/bash -x ./stage21-USER-neutron-user.sh 2>&1 | tee log/s21.log
printf "\n Next? \n"
read varkey
clear
sudo /bin/bash -x ./stage22-SUDO-neutron.sh 2>&1 | tee log/s22.log
printf "\n End 22 \n"
#sudo /bin/bash -x ./stageFIN-SUDO-postinstall.sh

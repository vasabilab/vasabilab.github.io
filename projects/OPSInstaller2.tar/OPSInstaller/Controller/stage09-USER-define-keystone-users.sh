# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
# run as a user
#
#!/bin/bash -x
cd $HOME/OPSInstaller/Controller
pwd
echo "Run this script as a user."
echo -n "1. create ADMIN user/tenant/role...press"
read varkey

export OS_SERVICE_TOKEN=vasabilab
export OS_SERVICE_ENDPOINT=http://controller:35357/v2.0

keystone user-create --name=admin --pass=vasabilab --email=vasabi@vasabilab.com

keystone role-create --name=admin

keystone tenant-create --name=admin --description="Admin Tenant"

keystone user-role-add --user=admin --tenant=admin --role=admin

keystone user-role-add --user=admin --role=_member_ --tenant=admin

printf "\n2. create DEMO user/tenant/role...press"
read varkey
keystone user-create --name=demo --pass=vasabilab --email=demo@vasabilab.com

keystone tenant-create --name=demo --description="Demo Tenant"

keystone user-role-add --user=demo --role=_member_ --tenant=demo

printf "\n3. create service tenant...press"
read varkey
keystone tenant-create --name=service --description="Service Tenant"

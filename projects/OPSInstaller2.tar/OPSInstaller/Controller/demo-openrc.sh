export OS_USERNAME=demo
export OS_PASSWORD=vasabilab
export OS_TENANT_NAME=demo
export OS_AUTH_URL=http://controller:35357/v2.0

# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
# Run this with sudo or as root

#!/bin/bash -x
cd $HOME/OPSInstaller/Controller
pwd
apt-get -y install python-mysqldb mysql-server

printf "1. set my.cnf configuration... press\n" 
read varkey

cp files/my.cnf /etc/mysql/my.cnf

printf "3. restart mysql & delete anonymous acct... press\n"
read varkey

service mysql restart
mysql_install_db
mysql_secure_installation

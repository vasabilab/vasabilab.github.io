# Openstack icehouse installation script 
# on ubuntu 14.04 by kasidit chanchio
# vasabilab, dept of computer science, Thammasat University, Thailand
# copyright 2014 
#
#
#!/bin/bash -x
cd $HOME/OPSInstaller/Controller
pwd
echo "Run this script with sudo or as root."
echo -n "1. install nuetron...press"
read varkey
apt-get -y install neutron-server neutron-plugin-ml2

echo "add tenant_id to neutron.conf.. and set config files"
./produce-neutron-file-with-tenant-id.sh
#
cp files/neutron-gen.conf /etc/neutron/neutron.conf
cp files/ml2_conf.ini /etc/neutron/plugins/ml2/ml2_conf.ini
cp files/neutron-nova.conf /etc/nova/nova.conf

printf "\n2. restart nova and nuetron...press"
read varkey

service nova-api restart
service nova-scheduler restart
service nova-conductor restart
service neutron-server restart

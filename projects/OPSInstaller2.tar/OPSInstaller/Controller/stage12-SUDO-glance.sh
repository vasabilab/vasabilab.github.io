# Openstack icehouse installation script 
# on ubuntu 14.04 by kasidit chanchio
# vasabilab, dept of computer science, Thammasat University, Thailand
# copyright 2014 
#
#
#!/bin/bash -x
cd $HOME/OPSInstaller/Controller
pwd
echo "Run this script with sudo or as root."
echo -n "1. install glance...press"
read varkey

apt-get -y install glance python-glanceclient
cp files/glance-api.conf /etc/glance/glance-api.conf
cp files/glance-registry.conf /etc/glance/glance-registry.conf

rm /var/lib/glance/glance.sqlite

printf "\n2. create database tables...press"
read varkey
export MYSQL_PASS=vasabilab
mysql -u root -p$MYSQL_PASS -e "CREATE DATABASE glance;"
mysql -u root -p$MYSQL_PASS -e "GRANT ALL PRIVILEGES ON glance.* TO 'glance'@'localhost' IDENTIFIED BY 'vasabilab';"
mysql -u root -p$MYSQL_PASS -e "GRANT ALL PRIVILEGES ON glance.* TO 'glance'@'%' IDENTIFIED BY 'vasabilab';"

echo "su -s /bin/sh -c \"glance-manage db_sync\" glance"
su -s /bin/sh -c "glance-manage db_sync" glance

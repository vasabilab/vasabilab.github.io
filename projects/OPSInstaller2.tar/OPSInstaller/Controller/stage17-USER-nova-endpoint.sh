# Openstack icehouse installation script 
# on ubuntu 14.04 by kasidit chanchio
# vasabilab, dept of computer science, Thammasat University, Thailand
# copyright 2014 
#
#
#!/bin/bash -x
cd $HOME/OPSInstaller/Controller
pwd
echo "Run this script as a user."
echo -n "1. create nova user...press"
read varkey
source ./admin-openrc.sh
keystone user-create --name=nova --pass=vasabilab --email=nova@vasabilab.com
keystone user-role-add --user=nova --tenant=service --role=admin

printf "\n2. create nova endpoint...press"
read varkey
keystone service-create --name=nova --type=compute \
  --description="OpenStack Compute"
keystone endpoint-create \
  --service-id=$(keystone service-list | awk '/ compute / {print $2}') \
  --publicurl=http://controller:8774/v2/%\(tenant_id\)s \
  --internalurl=http://controller:8774/v2/%\(tenant_id\)s \
  --adminurl=http://controller:8774/v2/%\(tenant_id\)s

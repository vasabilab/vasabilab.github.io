#!/bin/bash -x 
#
# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
#
# run below before launch this script
printf "\nrun this command under ssh-agent.\n"

cd $HOME/OPSInstaller/Gateway
pwd
#
echo "Set initial OpenStack network"
read varkey
ssh vasabi@controller /bin/bash -x ./OPSInstaller/Controller/PART02-SET-INITIAL-NETWORK.sh | tee log/init-network.log
printf "\nNext, try http://controller/horizon\n"

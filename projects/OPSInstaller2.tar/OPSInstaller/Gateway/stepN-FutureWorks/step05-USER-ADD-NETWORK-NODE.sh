#!/bin/bash -x 
#
# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
#
# run below before launch this script
printf "\nrun this command under ssh-agent.\n"

cd $HOME/OPSInstaller/Gateway
pwd
#
echo "Add an OpenStack network node"
read varkey
ssh -t vasabi@network sudo ./OPSInstaller/Network/OPENSTACK-NETWORK-INSTALLER.sh | tee log/s2-network.log
printf "\nNext, you will add a compute node\n"

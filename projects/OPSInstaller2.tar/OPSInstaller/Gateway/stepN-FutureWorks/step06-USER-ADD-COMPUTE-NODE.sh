#!/bin/bash -x 
#
# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
#
# run below before launch this script
#
printf "\nrun this command under ssh-agent.\n"
cd $HOME/OPSInstaller/Gateway
pwd
#
echo "Add a compute node"
read varkey
ssh -t vasabi@compute sudo ./OPSInstaller/Compute/OPENSTACK-COMPUTE-INSTALLER.sh | tee log/s3-compute.log
printf "\nNext, you will add an initial network\n"

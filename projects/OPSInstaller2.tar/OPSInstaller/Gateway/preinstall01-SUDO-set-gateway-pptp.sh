# This script set a NAT gateway and PPTP VPN server
# Copyright 2014 kasidit chanchio
# It must be run as root. 
#!/bin/bash -x
echo "Run as root or sudo"
#

echo "1. copy files"
#cp files/interfaces /etc/network/interfaces
cp files/hosts /etc/hosts

cp files/sysctl.conf /etc/sysctl.conf
sysctl -w net.ipv4.ip_forward=1

cp files/rc.local /etc/rc.local

echo "2. install vpn server"
apt-get -y install pptpd
echo "localip 10.0.0.1" >> /etc/pptpd.conf
echo "remoteip 10.0.0.225-254" >> /etc/pptpd.conf
echo "ms-dns 8.8.8.8" >> /etc/ppp/pptpd-options
echo "ms-dns 8.8.4.4" >> /etc/ppp/pptpd-options
echo "vasabi * vasabilab *" >> /etc/ppp/chap-secrets
service pptpd restart
#
echo "3. set gateway"
/sbin/iptables -P FORWARD ACCEPT
/sbin/iptables --table nat -A POSTROUTING -o eth0 -j MASQUERADE
/sbin/iptables -A FORWARD -p tcp --syn -s 10.0.0.0/24 -j TCPMSS --clamp-mss-to-pmtu
#
# restart network 
ifdown eth0
ifup eth0
ifdown eth1
ifup eth1
# reboot
printf "\n\nReboot this machine.\n"

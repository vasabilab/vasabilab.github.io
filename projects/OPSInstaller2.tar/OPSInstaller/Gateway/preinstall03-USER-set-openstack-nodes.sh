#!/bin/bash -x 
#
# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
#
# run below before launch this script
printf "\nyou are supposed to be running ssh-agent at this point.\n"
# --->ssh-agent /bin/bash
# --> ssh-add
# copy Installer 

cd $HOME/OPSInstaller/Gateway
pwd
echo "copy installer to nodes"
read varkey
scp OPSInstaller.tar vasabi@controller:/home/vasabi/OPSInstaller.tar
scp OPSInstaller.tar vasabi@network:/home/vasabi/OPSInstaller.tar
scp OPSInstaller.tar vasabi@compute:/home/vasabi/OPSInstaller.tar
#
echo "extract installer files"
read varkey
ssh vasabi@controller tar xvf /home/vasabi/OPSInstaller.tar | tee log/extract-controller-current.log
ssh vasabi@network tar xvf /home/vasabi/OPSInstaller.tar | tee log/extract-network-current.log
ssh vasabi@compute tar xvf /home/vasabi/OPSInstaller.tar | tee log/extract-compute-current.log
#
#echo "01. preinstall controller"
#read varkey
#ssh -t vasabi@controller sudo ./OPSInstaller/Controller/stage01-SUDO-preinstall.sh | tee log/s1.log
#echo "02. preinstall network"
#read varkey
#ssh -t vasabi@network sudo ./OPSInstaller/Network/stage02-SUDO-network-preinstall.sh | tee log/s2.log
#echo "03. preinstall compute"
#read varkey
#ssh -t vasabi@compute sudo ./OPSInstaller/Compute/stage03-SUDO-compute-preinstall.sh | tee log/s3.log
#
printf "\n\nFor debugging purposes, I suggest you login to the coltroller, \nthe network, and the compute nodes to run installation script step-by-step.\n"


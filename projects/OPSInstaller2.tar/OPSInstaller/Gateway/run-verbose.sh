# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
#!/bin/bash -x
#
case $1 in 
	0) sudo /bin/bash -x ./preinstall00-SUDO-update.sh 2>&1 | tee log/s00.log; printf "\nnext: ./run-verbose.sh 1\n" ;;
	1) sudo /bin/bash -x ./preinstall01-SUDO-set-gateway-pptp.sh 2>&1 | tee log/s01.log ; printf "\nnext: ./run-verbose.sh 2\n" ;;
	2) /bin/bash -x ./preinstall02-USER-set-remote-access.sh 2>&1 | tee log/s02.log ; printf "\nnext: ./run-verbose.sh 3\n"  ;;
	3) /bin/bash -x ./preinstall03-USER-set-openstack-nodes.sh 2>&1 | tee log/s03.log ; printf "next, on controller node: ./run-verbose.sh 0\n" ;;
	*) printf "\ninvalid parameter value!\n" ;;
esac

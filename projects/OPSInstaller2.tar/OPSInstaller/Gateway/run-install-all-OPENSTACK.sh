#!/bin/bash -x 
#
# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014 vasabilab team 
#
#
# run below before launch this script
printf "\nrun this command under ssh-agent.\n"

cd $HOME/OPSInstaller/Gateway
pwd
#
echo "Install OpenStack"
read varkey
ssh -t vasabi@controller sudo ./OPSInstaller/Controller/stage00-SUDO-update.sh | tee log/s00-controller.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller sudo ./OPSInstaller/Controller/stage01-SUDO-preinstall.sh | tee log/s01.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@network sudo ./OPSInstaller/Network/stage00-SUDO-update.sh | tee log/s00-network.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@network sudo ./OPSInstaller/Network/stage02-SUDO-network-preinstall.sh | tee log/s02.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@compute sudo ./OPSInstaller/Compute/stage00-SUDO-update.sh | tee log/s00-compute.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@compute sudo ./OPSInstaller/Compute/stage03-SUDO-compute-preinstall.sh | tee log/s03.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller sudo ./OPSInstaller/Controller/stage04-SUDO-mysql.sh | tee log/s04.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@network sudo ./OPSInstaller/Network/stage05-SUDO-network-mysql.sh | tee log/s05.log
printf "\n Next? Stages\n"
read varkey
clear
ssh -t vasabi@compute sudo ./OPSInstaller/Compute/stage06-SUDO-compute-mysql.sh | tee log/s06.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller sudo ./OPSInstaller/Controller/stage07-SUDO-rabbit.sh | tee log/s07.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller sudo ./OPSInstaller/Controller/stage08-SUDO-keystone.sh | tee log/s08.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller ./OPSInstaller/Controller/stage09-USER-define-keystone-users.sh | tee log/s09.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller ./OPSInstaller/Controller/stage10-USER-service-endpoints.sh | tee log/s10.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller sudo ./OPSInstaller/Controller/stage11-SUDO-install-pip.sh | tee log/s11.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller sudo ./OPSInstaller/Controller/stage12-SUDO-glance.sh | tee log/s12.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller ./OPSInstaller/Controller/stage13-USER-glance-endpoint.sh | tee log/s13.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller sudo ./OPSInstaller/Controller/stage14-SUDO-restart-glance.sh | tee log/s14.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller ./OPSInstaller/Controller/stage15-USER-verify-glance.sh | tee log/s15.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller sudo ./OPSInstaller/Controller/stage16-SUDO-control-nova.sh | tee log/s16.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller ./OPSInstaller/Controller/stage17-USER-nova-endpoint.sh | tee log/s17.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller sudo ./OPSInstaller/Controller/stage18-SUDO-restart-nova.sh | tee log/s18.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller ./OPSInstaller/Controller/stage19-USER-verify-nova.sh | tee log/s19.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@compute sudo ./OPSInstaller/Compute/stage20-SUDO-nova-comp.sh | tee log/s20.log
printf "\n Next? stages\n"
read varkey
clear
ssh -t vasabi@controller ./OPSInstaller/Controller/stage21-USER-neutron-endpoint.sh | tee log/s21.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller sudo ./OPSInstaller/Controller/stage22-SUDO-neutron.sh | tee log/s22.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@network sudo ./OPSInstaller/Network/stage23-SUDO-network-neutron.sh | tee log/s23.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller sudo ./OPSInstaller/Controller/stage24-SUDO-reconfig-nova.sh | tee log/s24.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@network sudo ./OPSInstaller/Network/stage25-SUDO-set-ml2.sh | tee log/s25.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@compute sudo ./OPSInstaller/Compute/stage26-SUDO-neutron-comp.sh | tee log/s26.log
printf "\n Next stages reboot all \n"
read varkey
# reboot
ssh -t vasabi@controller sudo reboot
ssh -t vasabi@network sudo reboot
ssh -t vasabi@compute sudo reboot
clear
printf "\n Wait until all machines are back before proceed. Type anykey\n"
read varkey
ssh -t vasabi@network sudo ./OPSInstaller/Network/stage26-SUDO-set-ovs.sh | tee log/s25.log
printf "\n Next stages? \n"
read varkey
ssh -t vasabi@controller ./OPSInstaller/Controller/stage27-USER-initial-net.sh | tee log/s27.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller ./OPSInstaller/Controller/stage28-USER-demo-net.sh | tee log/s28.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller sudo ./OPSInstaller/Controller/stage29-SUDOONLY-dashboard.sh | tee log/s29.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller sudo ./OPSInstaller/Controller/stage30-SUDOONLY-apache.sh | tee log/s30.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller sudo ./OPSInstaller/Controller/stage31-SUDO-cinder-install.sh | tee log/s31.log
printf "\n Next stages? \n"
read varkey

# Openstack icehouse installation script 
# on ubuntu 14.04 by kasidit chanchio
# vasabilab, dept of computer science, Thammasat University, Thailand
# copyright 2014 
#
# run with sudo or as root.
#
#!/bin/bash -x
cd $HOME/OPSInstaller/Compute
pwd
printf "\nRun as root\n1. install nova\n"
read varkey
apt-get -y install nova-compute-kvm python-guestfs
cp files/nova.conf /etc/nova/nova.conf
cp files/nova-compute.conf /etc/nova/nova-compute.conf

printf "\n2. create statoverride \n"
read varkey
dpkg-statoverride  --update --add root root 0644 /boot/vmlinuz-$(uname -r)

cp files/statoverride /etc/kernel/postinst.d/statoverride
chmod +x /etc/kernel/postinst.d/statoverride

rm /var/lib/nova/nova.sqlite

printf "\n3. restart nova compute \n"
read varkey
service nova-compute restart

# Openstack icehouse installation script 
# on ubuntu 14.04 by kasidit chanchio
# vasabilab, dept of computer science, Thammasat University, Thailand
# copyright 2014 
#
# run with sudo or as root.
#
#!/bin/bash -x
cd $HOME/OPSInstaller/Compute
pwd
printf "1. set interface/hosts files\n"
read varkey
cp files/interfaces /etc/network/interfaces
cp files/hosts /etc/hosts

printf "2. set ntp server\n"
read varkey
apt-get -y install ntp
cp files/ntp.conf /etc/ntp.conf

printf "3. restart services\n"
read varkey
ifdown eth0
ifup eth0
ifdown eth1
ifup eth1
#
# prevent fragmentation
#
ifconfig eth0 mtu 1700
ifconfig eth1 mtu 1700
#
service ntp restart
sleep 5
# restore later 
cp /etc/sudoers files/sudoers.save
echo "vasabi ALL=NOPASSWD: ALL" >> /etc/sudoers
#
ifconfig

# Openstack icehouse installation script 
# on ubuntu 14.04 by kasidit chanchio
# vasabilab, dept of computer science, Thammasat University, Thailand
# copyright 2014 
#
# run with sudo or as root.
#
#!/bin/bash -x
cd $HOME/OPSInstaller/Compute
pwd
printf "\nRun as root\n1. set sysctl \n"
read varkey
echo "net.ipv4.conf.all.rp_filter=0" >> /etc/sysctl.conf
echo "net.ipv4.conf.default.rp_filter=0" >> /etc/sysctl.conf
sysctl -p

printf "\n2. install neutron \n"
read varkey
apt-get -y install neutron-common neutron-plugin-ml2 neutron-plugin-openvswitch-agent
cp files/neutron.conf /etc/neutron/neutron.conf
cp files/ml2_conf.ini /etc/neutron/plugins/ml2/ml2_conf.ini

service openvswitch-switch restart
ovs-vsctl add-br br-int
printf "\n2. reconfig nova & restart\n"
read varkey

cp files/nova_stage26.conf /etc/nova/nova.conf

service nova-compute restart
service neutron-plugin-openvswitch-agent restart

# Openstack icehouse installation script 
# on ubuntu 14.04 by kasidit chanchio
# vasabilab, dept of computer science, Thammasat University, Thailand
# copyright 2014 
#
#!/bin/bash -x
cd $HOME/OPSInstaller/Network
pwd
echo "Run with sudo or as root."
#

printf "1. set openvswitch to fix external down \n"
read varkey
ovs-vsctl br-set-external-id br-ex bridge-id br-ex
service neutron-plugin-openvswitch-agent restart

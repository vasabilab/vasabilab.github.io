# Openstack icehouse installation script 
# on ubuntu 14.04 by kasidit chanchio
# vasabilab, dept of computer science, Thammasat University, Thailand
# copyright 2014 
#
#!/bin/bash -x
cd $HOME/OPSInstaller/Network
pwd
echo "Run with sudo or as root."
#
printf "1. copy ml2 config file \n"
read varkey
cp files/ml2_conf.ini /etc/neutron/plugins/ml2/ml2_conf.ini

printf "2. configure openvswitch service \n"
read varkey
service openvswitch-switch restart
ovs-vsctl add-br br-int
ovs-vsctl add-br br-ex
ovs-vsctl add-port br-ex eth2

printf "3. restart neutron\n"
read varkey
service neutron-plugin-openvswitch-agent restart
service neutron-l3-agent restart
service neutron-dhcp-agent restart
service neutron-metadata-agent restart

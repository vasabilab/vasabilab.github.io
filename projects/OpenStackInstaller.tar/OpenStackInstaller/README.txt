The "OPSInstaller" OpenStack Icehouse Installation Script 

Copyright 2014 Kasidit Chanchio 

This set of script files were developed to assist the 
OpenStack Installation. The testing and training were 
done with many helps from the vasabilab team members, 
including: 
	Vasinee Siripoon
	Somkiat Kosolsombat
	Phithak Thaenkaew
	Chayawat Pechwises

Contact: kasiditchanchio@gmail.com

Note: This script is written for education purpose. 
For more information, please consult the following 
documents: 

1. http://vasabilab.cs.tu.ac.th/projects/OpenStackIcehouseInstall.pdf 
2. http://docs.openstack.org/icehouse/install-guide/install/apt/content/
 

#!/bin/bash -x 
#
# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014 vasabilab team 
#
#
# run below before launch this script
printf "\nrun this command under ssh-agent.\n"

cd $HOME/OPSInstaller/Gateway
pwd
#
echo "Install OpenStack"
read varkey
ssh -t vasabi@controller sudo ./OPSInstaller/Controller/stage04-SUDO-mysql.sh | tee log/s04.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@network sudo ./OPSInstaller/Network/stage05-SUDO-network-mysql.sh | tee log/s05.log
printf "\n Next? Stages\n"
read varkey
clear
ssh -t vasabi@compute sudo ./OPSInstaller/Compute/stage06-SUDO-compute-mysql.sh | tee log/s06.log
printf "\n Next stages? \n"
read varkey
clear
ssh vasabi@controller /bin/bash -x ./OPSInstaller/Controller/INSTALL-S07-S19.sh | tee log/s07-19.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@compute sudo ./OPSInstaller/Compute/stage20-SUDO-nova-comp.sh | tee log/s20.log
printf "\n Next? stages\n"
read varkey
clear
ssh vasabi@controller /bin/bash -x ./OPSInstaller/Controller/INSTALL-S21-S22.sh | tee log/s21-22.log
printf "\n Next? stages\n"
read varkey
clear
ssh -t vasabi@network sudo ./OPSInstaller/Network/stage23-SUDO-network-neutron.sh | tee log/s23.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller sudo ./OPSInstaller/Controller/stage24-SUDO-reconfig-nova.sh | tee log/s24.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@network sudo ./OPSInstaller/Network/stage25-SUDO-set-ml2.sh | tee log/s25.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@compute sudo ./OPSInstaller/Compute/stage26-SUDO-neutron-comp.sh | tee log/s26.log
printf "\n Next stages reboot all \n"
read varkey
# reboot
ssh -t vasabi@controller sudo reboot
ssh -t vasabi@network sudo reboot
ssh -t vasabi@compute sudo reboot
clear
ssh vasabi@controller /bin/bash -x ./OPSInstaller/Controller/INSTALL-S27-S30.sh | tee log/s27-30.log
printf "\n Done... \n"
read varkey

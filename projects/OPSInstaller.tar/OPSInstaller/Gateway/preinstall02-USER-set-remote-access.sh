# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
#!/bin/bash -x 
#
ssh-keygen -t rsa
scp /home/vasabi/.ssh/id_rsa.pub vasabi@controller:/home/vasabi/authorized_keys
scp /home/vasabi/.ssh/id_rsa.pub vasabi@network:/home/vasabi/authorized_keys
scp /home/vasabi/.ssh/id_rsa.pub vasabi@compute:/home/vasabi/authorized_keys

ssh  vasabi@controller "(mkdir /home/vasabi/.ssh; mv /home/vasabi/authorized_keys /home/vasabi/.ssh/authorized_keys)"
ssh  vasabi@network "(mkdir /home/vasabi/.ssh; mv /home/vasabi/authorized_keys /home/vasabi/.ssh/authorized_keys)"
ssh  vasabi@compute "(mkdir /home/vasabi/.ssh; mv /home/vasabi/authorized_keys /home/vasabi/.ssh/authorized_keys)"

echo "Next, you may run ssh-agent; ssh-add and openstak setup script"

# Openstack icehouse installation script 
# on ubuntu 14.04 by kasidit chanchio
# vasabilab, dept of computer science, Thammasat University, Thailand
# copyright 2014 
#
#
#!/bin/bash -x
cd $HOME/OPSInstaller/Controller
pwd
echo "Run this script as a user."
echo -n "1. create glance user...press"
read varkey
source ./admin-openrc.sh
keystone user-create --name=glance --pass=vasabilab \
   --email=glance@vasabilab.com
keystone user-role-add --user=glance --tenant=service --role=admin

printf "\n2. create glance endpoint...press"
read varkey
keystone service-create --name=glance --type=image \
  --description="OpenStack Image Service"

keystone endpoint-create \
  --service-id=$(keystone service-list | awk '/ image / {print $2}') \
  --publicurl=http://controller:9292 \
  --internalurl=http://controller:9292 \
  --adminurl=http://controller:9292

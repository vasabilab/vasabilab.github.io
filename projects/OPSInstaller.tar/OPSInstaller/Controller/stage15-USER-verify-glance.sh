# Openstack icehouse installation script 
# on ubuntu 14.04 by kasidit chanchio
# vasabilab, dept of computer science, Thammasat University, Thailand
# copyright 2014 
#
#
#!/bin/bash -x
cd $HOME/OPSInstaller/Controller
pwd
echo "Run this script as a user."
echo -n "1. get cirros image...press"
read varkey
source ./admin-openrc.sh
wget http://cdn.download.cirros-cloud.net/0.3.2/cirros-0.3.2-x86_64-disk.img

printf "\n2. upload cirros image...press"
read varkey
glance image-create --name "cirros-0.3.2-x86_64" --disk-format qcow2 \
  --container-format bare --is-public True --progress < cirros-0.3.2-x86_64-disk.img

printf "\n3. list glnace images and remove cirros file..."
glance image-list

rm cirros-0.3.2-x86_64-disk.img

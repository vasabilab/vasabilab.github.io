# Openstack icehouse installation script 
# on ubuntu 14.04 by kasidit chanchio
# vasabilab, dept of computer science, Thammasat University, Thailand
# copyright 2014 
#
#
#!/bin/bash -x
cd $HOME/OPSInstaller/Controller
pwd
echo "Run this script WITH sudo 'cos apache requires that!"
echo -n "1. install dashboard...press"
read varkey
apt-get -y install apache2 memcached libapache2-mod-wsgi openstack-dashboard
apt-get -y remove --purge openstack-dashboard-ubuntu-theme


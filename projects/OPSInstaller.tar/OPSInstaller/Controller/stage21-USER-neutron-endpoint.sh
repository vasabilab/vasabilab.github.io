# Openstack icehouse installation script 
# on ubuntu 14.04 by kasidit chanchio
# vasabilab, dept of computer science, Thammasat University, Thailand
# copyright 2014 
#
#
#!/bin/bash -x
cd $HOME/OPSInstaller/Controller
pwd
echo "Run this script as a user."
printf "\n1. create neutron database...press"
read varkey

export MYSQL_PASS=vasabilab
mysql -u root -p$MYSQL_PASS -e "CREATE DATABASE neutron;"
mysql -u root -p$MYSQL_PASS -e "GRANT ALL PRIVILEGES ON neutron.* TO 'neutron'@'localhost' IDENTIFIED BY 'vasabilab';"
mysql -u root -p$MYSQL_PASS -e "GRANT ALL PRIVILEGES ON neutron.* TO 'neutron'@'%' IDENTIFIED BY 'vasabilab';"

echo "su -s /bin/sh -c \"keystone-manage db_sync\" keystone"

printf "\n2. create neutron user, link to service tenant, create neutron service...press"
read varkey
source ./admin-openrc.sh
keystone user-create --name neutron --pass vasabilab --email neutron@vasabilab.com
keystone user-role-add --user neutron --tenant service --role admin
keystone service-create --name neutron --type network --description "OpenStack Networking"
keystone endpoint-create \
  --service-id $(keystone service-list | awk '/ network / {print $2}') \
  --publicurl http://controller:9696 \
  --adminurl http://controller:9696 \
  --internalurl http://controller:9696

printf "\n3. You must add the service Id below\nto the nova_admin_tenant_id in the files/neuton.conf file\n the next script should do that for you...press"
read varkey
keystone tenant-get service

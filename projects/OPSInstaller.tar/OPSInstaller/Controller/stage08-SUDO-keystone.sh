# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
# run with sudo or as root.
#
#!/bin/bash -x
cd $HOME/OPSInstaller/Controller
pwd
echo -n "1. install keystone..  press" 
read varkey
apt-get -y install keystone
cp files/keystone.conf /etc/keystone/keystone.conf 
rm /var/lib/keystone/keystone.db

echo -n "2. create keystone database user...press"
read varkey
#
export MYSQL_PASS=vasabilab
mysql -u root -p$MYSQL_PASS -e "CREATE DATABASE keystone;"
mysql -u root -p$MYSQL_PASS -e "GRANT ALL PRIVILEGES ON keystone.* TO 'keystone'@'localhost' IDENTIFIED BY 'vasabilab';"
mysql -u root -p$MYSQL_PASS -e "GRANT ALL PRIVILEGES ON keystone.* TO 'keystone'@'%' IDENTIFIED BY 'vasabilab';"
#
echo "su -s /bin/sh -c \"keystone-manage db_sync\" keystone"
su -s /bin/sh -c "keystone-manage db_sync" keystone
#
service keystone restart
printf "add crontab to clear old credentials\n"
#
(crontab -l -u keystone 2>&1 | grep -q token_flush) || \
echo '@hourly /usr/bin/keystone-manage token_flush >/var/log/keystone/keystone-tokenflush.log 2>&1' >> /var/spool/cron/crontabs/keystone

# copyright 2014 kasidit chanchio
. ./admin-openrc.sh
keystone tenant-get service | awk '/ id / {print $4}' 


# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
#!/bin/bash -x
#
# Perform 27 and 28 after the network node is started
#!/bin/bash -x
cd $HOME/OPSInstaller/Controller
pwd
/bin/bash -x ./stage27-USER-initial-net.sh 2>&1 | tee log/s27.log
printf "\n Next? \n"
read varkey
clear
/bin/bash -x ./stage28-USER-demo-net.sh 2>&1 | tee log/s28.log
printf "\n Set initial network \n"
read varkey
clear
sudo /bin/bash -x ./stage29-SUDOONLY-dashboard.sh 2>&1 | tee log/s29.log
printf "\n Next? \n"
read varkey
clear
sudo /bin/bash -x ./stage30-SUDOONLY-apache.sh 2>&1 | tee log/s30.log
read varkey
clear
printf "\n Done for now... try http://controller/horizon/ \n"

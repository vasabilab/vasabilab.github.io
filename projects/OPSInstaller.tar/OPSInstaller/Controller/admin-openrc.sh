export OS_USERNAME=admin
export OS_PASSWORD=vasabilab
export OS_TENANT_NAME=admin
export OS_AUTH_URL=http://controller:35357/v2.0

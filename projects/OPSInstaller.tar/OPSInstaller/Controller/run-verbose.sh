# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
#!/bin/bash -x
#
printf "(Note: if on vbox, you may want to make a vm snapshot before startint the installation.)\n\n" 
case $1 in 
	0) sudo /bin/bash -x ./stage00-SUDO-update.sh 2>&1 | tee log/s00.log; \
		printf "\nnext: ./run-verbose.sh 1\n (Note: See if any error occur! \ 
		May want to use a local mirror of ubuntu repo for reliable installation.)\n" ;;
	1) sudo /bin/bash -x ./stage01-SUDO-preinstall.sh 2>&1 | tee log/s01.log ; \
		printf "\nnext, on network node: ./run-verbose.sh 0\n (Note: if you are \
		using vbox, you may want to make a vm snapshot here. \n Also ping other \
		machines to check the network.)\n" ;;
	4) sudo /bin/bash -x ./stage04-SUDO-mysql.sh 2>&1 | tee log/s04.log ; \
		printf "\nnext, on network node: ./run-verbose.sh 5\n" ;;
	7) sudo /bin/bash -x ./stage07-SUDO-rabbit.sh 2>&1 | tee log/s07.log ;\
		printf "\nnext: ./run-verbose.sh 8\n" ;;
	8) sudo /bin/bash -x ./stage08-SUDO-keystone.sh 2>&1 | tee log/s08.log ; \
		printf "\nnext: ./run-verbose.sh 9\n" ;;
	9) /bin/bash -x ./stage09-USER-define-keystone-users.sh 2>&1 | tee log/s09.log ;\
		printf "\nnext: ./run-verbose.sh 10\n" ;;
	10) /bin/bash -x ./stage10-USER-service-endpoints.sh 2>&1 | tee log/s10.log ;\
		printf "\nnext: ./run-verbose.sh 11\n" ;;
	11) sudo /bin/bash -x ./stage11-SUDO-install-pip.sh 2>&1 | tee log/s11.log ; \
		printf "\nnext: ./run-verbose.sh 12\n" ;;
	12) sudo /bin/bash -x ./stage12-SUDO-glance.sh 2>&1 | tee log/s12.log ;\
		printf "\nnext: ./run-verbose.sh 13\n" ;;
	13) /bin/bash -x ./stage13-USER-glance-endpoint.sh 2>&1 | tee log/s13.log ;\
		printf "\nnext: ./run-verbose.sh 14\n" ;;
	14) sudo /bin/bash -x ./stage14-SUDO-restart-glance.sh 2>&1 | tee log/s14.log ;\
		printf "\nnext: ./run-verbose.sh 15\n " ;;
	15) /bin/bash -x ./stage15-USER-verify-glance.sh 2>&1 | tee log/s15.log ;\
		printf "\nnext: ./run-verbose.sh 16\n (Note: glance is done! may create \ 
		another vbox snapshot)\n" ;;
	16) sudo /bin/bash -x ./stage16-SUDO-control-nova.sh 2>&1 | tee log/s16.log ; \
		printf "\nnext: ./run-verbose.sh 17\n" ;;
	17) /bin/bash -x ./stage17-USER-nova-endpoint.sh 2>&1 | tee log/s17.log ; \
		printf "\nnext: ./run-verbose.sh 18\n" ;;
	18) sudo /bin/bash -x ./stage18-SUDO-restart-nova.sh 2>&1 | tee log/s18.log ; \
		printf "\nnext: ./run-verbose.sh 19\n" ;;
	19) /bin/bash -x ./stage19-USER-verify-nova.sh 2>&1 | tee log/s19.log ; \
		printf "\nnext on compute node: ./run-verbose.sh 20\n (Note: After  \
		run the script command at the compute node, come back here and \
		run\n\n sudo nova-manage service list \n\n to check nova-compute.\n \
                Also, you may want to run\n\n netstat -l \n\nto see if services\n \
		are listening at appropriate ports.\n  \
		if all is okay, reboot the controller and compute machines, \n  \
		check all those service list and ports again,\n \
		and then run \"./run-verbose.sh 21\". \n \
		Oh, yes, one more thing! if no vbox, better make a snapshot after reboot too.)\n" ;;
	21) /bin/bash -x ./stage21-USER-neutron-endpoint.sh 2>&1 | tee log/s21.log ; \
		printf "\nnext: ./run-verbose.sh 22\n" ;;
	22) sudo /bin/bash -x ./stage22-SUDO-neutron.sh 2>&1 | tee log/s22.log ; \
		printf "\nnext on network: ./run-verbose.sh 23\n" ;;
	24) sudo /bin/bash -x ./stage24-SUDO-reconfig-nova.sh 2>&1 | tee log/s24.log ; \
		printf "\nnext on network: ./run-verbose.sh 25\n (Note: \
		reboot all after finish ./run-verbose.sh 27)\n" ;;
	27) /bin/bash -x ./stage27-USER-initial-net.sh 2>&1 | tee log/s27.log ; \
		printf "\nnext: ./run-verbose.sh 28\n" ;;
	28) /bin/bash -x ./stage28-USER-demo-net.sh 2>&1 | tee log/s28.log ; \
		printf "\nnext: ./run-verbose.sh 29\n" ;;
	29) sudo /bin/bash -x ./stage29-SUDOONLY-dashboard.sh 2>&1 | tee log/s29.log ; \
		printf "\nnext: ./run-verbose.sh 30\n" ;;
	30) sudo /bin/bash -x ./stage30-SUDOONLY-apache.sh 2>&1 | tee log/s30.log ; \
		printf "\nnext: ./run-verbose.sh 30\n" ;;
	31) sudo /bin/bash -x ./stage31-SUDO-cinder-install.sh 2>&1 | tee log/s31.log ; \
		printf "\nnext: that's it for now!\n" ;;
	*) printf "\ninvalid parameter value!\n" ;;
esac

# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014 Phithak Teankaew 
#
#!/bin/bash -x
# Cinder Controller ------------------------------------------------

source ./admin-openrc.sh

apt-get -y install cinder-api cinder-scheduler

echo "[DEFAULT]" > /etc/cinder/cinder.conf
echo "rootwrap_config = /etc/cinder/rootwrap.conf" >> /etc/cinder/cinder.conf
echo "api_paste_confg = /etc/cinder/api-paste.ini" >> /etc/cinder/cinder.conf
echo "iscsi_helper = tgtadm" >> /etc/cinder/cinder.conf
echo "volume_name_template = volume-%s" >> /etc/cinder/cinder.conf
echo "volume_group = cinder-volumes" >> /etc/cinder/cinder.conf
echo "verbose = True" >> /etc/cinder/cinder.conf
echo "auth_strategy = keystone" >> /etc/cinder/cinder.conf
echo "state_path = /var/lib/cinder" >> /etc/cinder/cinder.conf
echo "lock_path = /var/lock/cinder" >> /etc/cinder/cinder.conf
echo "volumes_dir = /var/lib/cinder/volumes" >> /etc/cinder/cinder.conf
echo "rpc_backend = cinder.openstack.common.rpc.impl_kombu" >> /etc/cinder/cinder.conf
echo "rabbit_host = controller" >> /etc/cinder/cinder.conf
echo "rabbit_port = 5672" >> /etc/cinder/cinder.conf
echo "rabbit_userid = guest" >> /etc/cinder/cinder.conf
echo "rabbit_password = vasabilab" >> /etc/cinder/cinder.conf
echo "glance_host = controller" >> /etc/cinder/cinder.conf
echo "" >> /etc/cinder/cinder.conf
echo "[database]" >> /etc/cinder/cinder.conf
echo "connection = mysql://cinder:vasabilab@controller/cinder" >> /etc/cinder/cinder.conf
echo "" >> /etc/cinder/cinder.conf
echo "[keystone_authtoken]" >> /etc/cinder/cinder.conf
echo "auth_uri = http://controller:5000" >> /etc/cinder/cinder.conf
echo "auth_host = controller" >> /etc/cinder/cinder.conf
echo "auth_port = 35357" >> /etc/cinder/cinder.conf
echo "auth_protocol = http" >> /etc/cinder/cinder.conf
echo "admin_tenant_name = service" >> /etc/cinder/cinder.conf
echo "admin_user = cinder" >> /etc/cinder/cinder.conf
echo "admin_password = vasabilab" >> /etc/cinder/cinder.conf

mysql -u root -pvasabilab -e "CREATE DATABASE cinder"
mysql -u root -pvasabilab -e "GRANT ALL PRIVILEGES ON cinder.* TO 'cinder'@'localhost' IDENTIFIED BY 'vasabilab'"
mysql -u root -pvasabilab -e "GRANT ALL PRIVILEGES ON cinder.* TO 'cinder'@'%' IDENTIFIED BY 'vasabilab'"

su -s /bin/sh -c "cinder-manage db sync" cinder

keystone user-create --name=cinder --pass=vasabilab --email=cinder@vasabilab.com
keystone user-role-add --user=cinder --tenant=service --role=admin

keystone service-create --name=cinder --type=volume --description="OpenStack Block Storage"
keystone endpoint-create \
  --service-id=$(keystone service-list | awk '/ volume / {print $2}') \
  --publicurl=http://controller:8776/v1/%\(tenant_id\)s \
  --internalurl=http://controller:8776/v1/%\(tenant_id\)s \
  --adminurl=http://controller:8776/v1/%\(tenant_id\)s

keystone service-create --name=cinderv2 --type=volumev2 --description="OpenStack Block Storage v2"
keystone endpoint-create \
  --service-id=$(keystone service-list | awk '/ volumev2 / {print $2}') \
  --publicurl=http://controller:8776/v2/%\(tenant_id\)s \
  --internalurl=http://controller:8776/v2/%\(tenant_id\)s \
  --adminurl=http://controller:8776/v2/%\(tenant_id\)s

service cinder-scheduler restart
service cinder-api restart

# Cinder Node ------------------------------------------------------

apt-get -y install lvm2 cinder-volume

mkdir /home/cinder
chown -R cinder.cinder /home/cinder
dd if=/dev/zero of=/home/cinder/cinder-volumes bs=1 count=0 seek=2G
losetup /dev/loop2 /home/cinder/cinder-volumes
sleep 5

pvcreate /dev/loop2
vgcreate cinder-volumes /dev/loop2
pvscan

sed -i 's/exit 0//g' /etc/rc.local
echo "losetup /dev/loop2 /home/cinder/cinder-volumes" >> /etc/rc.local
echo "sleep 5" >> /etc/rc.local
echo "service cinder-volume restart" >> /etc/rc.local
echo "service tgt restart" >> /etc/rc.local
echo "" >> /etc/rc.local
echo "exit 0" >> /etc/rc.local

service cinder-volume restart
service tgt restart
